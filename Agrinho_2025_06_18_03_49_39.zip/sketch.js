function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let player1, player2;

let obstacles = [];

let score = 0;

let level = 1;

let deliveryZone;

let message = "Unindo forças: Campo e Cidade!";

let showInstructions = true;

let celebrationTimer = 0;

function setup() {

  createCanvas(800, 600);

  player1 = new Player(100, height/2, 'Campo', 'rgb(0,0,0)', 'WASD');

  player2 = new Player(width - 100, height/2, 'Cidade', 'rgb(0,0,0)', 'ARROWS')

  deliveryZone = createVector(width / 2, height / 2);

  textFont('Georgia');

}

function draw() {

  background(230);

  // Instruções iniciais

  if (showInstructions) {

    showStartInstructions();

    return;

  }

  // Zona de entrega

  fill(255, 220, 150);

  ellipse(deliveryZone.x, deliveryZone.y, 100);

  // Jogadores

  player1.update();

  player2.update();

  player1.show();

  player2.show();

  // Obstáculos

  for (let obs of obstacles) {

    obs.move();

    obs.show();

    if (obs.hits(player1) || obs.hits(player2)) {

      gameOver();

      return;

    }

  }

  // Entregas

  if (player1.deliver(deliveryZone) && player2.deliver(deliveryZone)) {

    score++;

    nextLevel();

  }

  // HUD

  fill(50);

  textSize(20);

  textAlign(LEFT);

  text(`Conexões: ${score}  |  Nível: ${level}`, 20, 30);

  text(message, 20, 60);

  // Comemoração

  if (celebrationTimer > 0) {

    celebrate();

    celebrationTimer--;

  }

}

function keyPressed() {

  if (showInstructions && key) {

    showInstructions = false;

  }

}

function showStartInstructions() {

  background(200, 240, 200);

  fill(30);

  textAlign(CENTER);

  textSize(32);

  text("🌾 Conexão Campo-Cidade 🏙️", width/2, 100);

  textSize(20);

  text("Dois jogadores, uma missão: cooperar para construir conexões!", width/2, 140);

  text("Controles:", width/2, 190);

  text("Jogador 1 (Campo) - Teclas W A S D", width/2, 220);

  text("Jogador 2 (Cidade) - Setas ← ↑ ↓ →", width/2, 250);

  text("Objetivo: Os dois jogadores devem chegar juntos à zona de entrega (círculo no meio).", width/2, 290);

  text("Cuidado com os obstáculos! 🧱", width/2, 320);

  text("Pressione qualquer tecla para começar!", width/2, 380);

}

function nextLevel() {

  level++;

  message = random([

    "🌟 Parceria que dá certo!",

    "🚜 A união faz a força!",

    "🌱 Crescendo juntos!",

    " Campo e Cidade: Conectados!",

    " Subiu de nível! Força total!"

  ]);

  player1.reset();

  player2.reset();

  obstacles.push(new Obstacle());

  celebrationTimer = 120; // frames de comemoração (~2 segundos)

}

function celebrate() {

  fill(random(255), random(255), random(255));

  textSize(40);

  textAlign(CENTER);

  text(" Conexão fortalecida! 🎉", width / 2, height / 2);

}

function gameOver() {

  background(0);

  fill(255, 0, 0);

  textSize(40);

  textAlign(CENTER);

  text("🚫 Conexão interrompida!", width / 2, height / 2 - 20);

  textSize(20);

  text("Pressione F5 para tentar novamente", width / 2, height / 2 + 20);

  noLoop();

}

// Player Class

class Player {

  constructor(x, y, label, color, control) {

    this.pos = createVector(x, y);

    this.size = 30;

    this.color = color;

    this.label = label;

    this.control = control;

    this.delivered = false;

  }

  update() {

    if (this.control === 'WASD') {

      if (keyIsDown(87)) this.pos.y -= 5; // W

      if (keyIsDown(83)) this.pos.y += 5; // S

      if (keyIsDown(65)) this.pos.x -= 5; // A

      if (keyIsDown(68)) this.pos.x += 5; // D

    } else {

      if (keyIsDown(UP_ARROW)) this.pos.y -= 5;

      if (keyIsDown(DOWN_ARROW)) this.pos.y += 5;

      if (keyIsDown(LEFT_ARROW)) this.pos.x -= 5;

      if (keyIsDown(RIGHT_ARROW)) this.pos.x += 5;

    }

    this.pos.x = constrain(this.pos.x, 0, width);

    this.pos.y = constrain(this.pos.y, 0, height);

  }

  show() {

    fill(this.color);

    ellipse(this.pos.x, this.pos.y, this.size);

    fill(255);

    textSize(12);

    textAlign(CENTER);

    text(this.label, this.pos.x, this.pos.y - 20);

  }

  deliver(target) {

    let d = dist(this.pos.x, this.pos.y, target.x, target.y);

    if (d < 50 && !this.delivered) {

      this.delivered = true;

      return true;

    }

    return false;

  }

  reset() {

    this.delivered = false;

    this.pos = createVector(this.control === 'WASD' ? 100 : width - 100, height / 2);

  }

}

// Obstáculo

class Obstacle {

  constructor() {

    this.pos = createVector(random(200, width - 200), random(height));

    this.speed = p5.Vector.random2D().mult(2 + level * 0.5);

    this.size = 40;

  }

  move() {

    this.pos.add(this.speed);

    if (this.pos.x < 0 || this.pos.x > width) this.speed.x *= -1;

    if (this.pos.y < 0 || this.pos.y > height) this.speed.y *= -1;

  }

  show() {

    fill(100);

    rectMode(CENTER);

    rect(this.pos.x, this.pos.y, this.size, this.size);

  }

  hits(player) {

    return dist(this.pos.x, this.pos.y, player.pos.x, player.pos.y) < (this.size + player.size) / 2;

  }

}